@echo off
start "" server.exe
start "" weight_nest.exe
